<?php

defined('ABSPATH') || die('403 Forbidden');

add_action('astra_footer_before', function () {
    // write your new footer here
});
