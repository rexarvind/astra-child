<?php

defined('ABSPATH') || die('403 Forbidden');

add_action('astra_masthead_bottom', function () {
    // write your new header here
});
