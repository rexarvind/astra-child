// Import our custom CSS
import '../scss/style.scss';

// Import which plugins you need
import {
  Alert,
  Button,
  // Carousel,
  Collapse,
  Dropdown,
  Modal,
  Offcanvas,
  // Popover,
  // ScrollSpy,
  Tab,
  // Toast,
  // Tooltip,
} from 'bootstrap';
