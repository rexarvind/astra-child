jQuery(function ($) {
    console.log('%c Byvex.com %c was here.', 'background:#1565c0;color:#ffffff;padding:4px 5px;border-radius:18px;', '');
});
