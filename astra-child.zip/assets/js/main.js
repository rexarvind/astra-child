jQuery(function ($) {
    if (typeof Swiper !== 'undefined') {
        // swiper slider code here
    }

    if (typeof tns === 'function') {
        // tiny slider code here
    }

    if ('owlCarousel' in $.fn && typeof $.fn.owlCarousel === 'function') {
        // owl carousel code here
    }

    if ('slick' in $.fn && typeof $.fn.slick === 'function') {
        // slick slider code here
    }

    if (typeof AOS !== 'undefined') {
        // AOS code at last here
    }

    console.log('Developed by %c Byvex.com %c', 'background:#1565c0;color:#ffffff;padding:4px 5px;border-radius:18px;', '');
});
